<?php
   if(isset($_POST["submit"]))
   {
    if(isset($_POST["firstname"])&& isset($_POST["lastname"]) && isset($_POST["date"]) && isset($_POST["conno"])&& isset($_POST["gen"]) && isset($_POST["email"])
&& isset($_POST["password"]) && isset($_POST["address"]) && isset($_POST["chek"]))  
  {
        $firstname=$_POST["firstname"];
        $lastname=$_POST["lastname"];
        $date=$_POST["date"];
        $conno=$_POST["conno"];
        $gen=$_POST["gen"];
        $email=$_POST["email"];
        $password=$_POST["password"];
        $address=$_POST["address"];
        $chek=$_POST["chek"];
    }
   }
   echo "First Name:",$firstname;
   echo "<br>";
   echo "Last Name:",$lastname;
   echo "<br>";
   echo "Birth Date:",$date;
   echo "<br>";
   echo "Contect NO:",$conno;
   echo "<br>";
   echo "Gender:",$gen;
   echo "<br>";
   echo "E-mail:",$email;
   echo "<br>";
   echo "Password:",$password;
   echo "<br>";
   echo "Address:",$address;
   echo "<br>";
   echo $chek; 
   echo "<br>";
   ?>
  
    
