<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" type="text/css"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <style type="text/css">
        #CNAForm {
            margin-top: 40px;
            margin-bottom: 40px;
            box-shadow: 0px 0px 3px gray;
            text-align: center;
            background-color: rgb(171, 161, 161);
        }

        i.fa,
        b {
            color: rgb(32, 35, 35);
        }
    </style>


</head>

<body>

    <form action="day2.php" method="post">

        <fieldset>
            <legend>Form Details</legend>

            <div class="container-fluid">
                <div class="row">
                    <div class="col-xs-12 col-sm-offset-3 col-sm-6 col-md-offset-4 col-md-4 col-lg-offset-4 col-lg-4"
                        id="CNAForm">
                        <h3 class="text-center"><i class="fa fa-users"></i> Create New Account
                            <hr>
                        </h3>
                        <div class="form-group">
                            <b>Firstname:</b>
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-user-circle"></i></span>
                                <input id="TxtFirstname" name="firstname" type="text" maxlength="20" placeholder="Enter firstname here.."
                                    class="form-control">
                            </div>
                        </div>
                        <div class="form-group">
                            <b>Lastname:</b>
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-user"></i></span>
                                <input id="TxtLastname" name="lastname" type="text" maxlength="20" placeholder="Enter lastname here.."
                                    class="form-control">
                            </div>
                        </div>
                        <div class="form-group">
                            <b>Birthdate:</b>
                            <div class="input-group">
                                <span class="input-group-addon"><b><i class="fa fa-birthday-cake"></i></b></span>
                                <input type="date" name="date" maxlength="20" class="form-control">
                            </div>
                        </div>
                        <div class="form-group">
                            <b><i class="fa fa-phone"></i> Contact No:</b>
                            <div class="input-group">
                                <span class="input-group-addon">`` <b>+91</b></span>
                                <input id="TxtContactNo" type="text" name="conno" maxlength="10"
                                    placeholder="Enter contact no. here.." class="form-control">
                            </div>
                        </div>
                        <div class="form-group">
                            <b>Gender:</b>
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-female"></i> | <i
                                        class="fa fa-male"></i></span>
                                <select class="form-control" id="DDL_Gender"name="gen">
                                    <option value="F">Female</option>
                                    <option value="M">Male</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <b>Email Id:</b>
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-envelope"></i></span>
                                <input id="TxtEmailId" type="text" name="email" maxlength="50" placeholder="Enter email id here.."
                                    class="form-control">
                            </div>
                        </div>
                        <div class="form-group">
                            <b>Password:</b>
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-LOCK"></i></span>
                                <input id="TxtPassword" type="password" maxlength="12" name="password"
                                    placeholder="Enter password here.." class="form-control">
                            </div>

                            <div class="form-group">
                                <b>address</b>
                                <div class="input-group">
                                    <span class="input-group-addon"><i class="fa fa-address-book"></i></span>
                                    <textarea rows="5" placeholder="Enter Address Here.." maxlength="500" name="address"
                                        class="form-control"></textarea>
                                    <hr />
                                </div>
                            </div>

                            <div class="form-group">

                                <input type="checkbox" name="chek"/> Accept Terms And Condition
                                <hr />
                            </div>

                            <div class="form-group">

                                <input name="submit" type="submit" class="btn btn-danger">
                            </div>

                        </div>
                    </div>
                </div>

        </fieldset>

    </form>

</body>

</html>